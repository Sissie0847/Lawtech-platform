# 🎨 美术协作工作包 Design Kit

> **LawTech 法律科技新闻卡片生成系统 - 美术协作专用包**  
> 版本: v2.0 | 更新日期: 2025-12-18

---

## 📦 包内文件清单

```
design_kit/
├── 📖 README.md                      ← 你正在看的文件（快速入门）
├── 📋 协作说明.md                    ← 详细的美术协作指南（必读）
├── 🎨 card_template_v2.html          ← 需要编辑的模板文件
├── 👀 card_preview_with_data.html    ← 浏览器预览文件（带真实数据）
├── 📊 news_edit_review.json          ← 示例新闻数据
├── 🖼️  qrcode.png                     ← 二维码图片
├── 🖼️  scale_icon.png                 ← 天平图标（用于头部）
├── 🖼️  calendar_icon.png              ← 日历图标（用于日期）
└── ⚡ quick_test.py                   ← 快速测试脚本（可选）
```

---

## 🚀 5 分钟快速上手

### Step 1: 预览当前样式

1. 双击打开 `card_preview_with_data.html`
2. 在浏览器中查看当前的卡片样式

### Step 2: 实时修改样式

1. 在浏览器中按 `F12` 打开开发者工具
2. 点击左上角的"选择元素"工具（或按 `Ctrl+Shift+C`）
3. 点击页面上你想修改的部分
4. 在右侧 Styles 面板中实时修改 CSS
5. 看到满意的效果后，记录下你的修改

### Step 3: 应用到模板文件

1. 用代码编辑器打开 `card_template_v2.html`
2. 在 `<style>` 标签内找到对应的 CSS
3. 应用你刚才的修改
4. 保存文件

### Step 4: 提交给开发同学

把修改好的 `card_template_v2.html` 发给开发同学即可！

---

## 🎯 常见修改任务

### ✨ 快速换色

在 `card_template_v2.html` 顶部找到这段代码：

```css
:root {
    --theme-blue: #489CC1;    /* 改这里换主题色 */
    --bg-color: #E6E9EF;      /* 改这里换背景色 */
}
```

**示例配色方案：**

- **科技紫：** `--theme-blue: #6C63FF;`
- **中国红：** `--theme-blue: #D32F2F;`
- **深色模式：** `--bg-color: #1a1a1a;`

### 📏 调整尺寸

```css
.container { 
    max-width: 600px;  /* 改大可以容纳更多内容 */
}

.banner-title {
    font-size: 2.8rem;  /* 改大让标题更突出 */
}
```

### 🎭 修改阴影效果

```css
box-shadow: 15px 15px 30px var(--shadow-dark), 
            -15px -15px 30px var(--shadow-light);
/* 数字越大，阴影越明显 */
```

---

## ⚠️ 重要提醒

### ✅ 可以随意修改：

- ✅ 所有 CSS 样式（颜色、字号、间距、阴影）
- ✅ HTML 布局和结构
- ✅ 固定文字（"LAWGEEK 晚读"等）
- ✅ 装饰元素和图标

### ❌ 请勿修改：

- ❌ `{{ xxx }}` 双花括号内容（这是数据占位符）
- ❌ `{% xxx %}` 百分号花括号（这是模板逻辑）
- ❌ JSON 数据文件（除非你要改示例内容）

---

## 📚 更多帮助

### 详细文档

请查看 **`协作说明.md`**，里面有：

- 详细的操作步骤
- 常见问题解答
- 设计示例和配色参考
- 浏览器开发者工具使用技巧

### 测试脚本

如果你懂一点 Python，可以运行：

```bash
cd design_kit
python quick_test.py
```

会自动生成 `test_output.png` 预览图。

---

## 🎨 设计风格说明

### 当前风格：新拟态 (Neumorphism)

**特点：**
- 柔和的阴影效果
- 浅色背景
- 圆润的边角
- 视觉上"浮雕"般的立体感

**适用场景：**
- 专业、简洁的内容展示
- 科技、金融、法律等领域

### 其他可选风格

- **扁平化 (Flat)：** 纯色、无阴影、极简
- **毛玻璃 (Glassmorphism)：** 半透明、模糊背景
- **赛博朋克 (Cyberpunk)：** 霓虹色、科技感

---

## 🔧 开发者备注

### 技术栈

- **模板引擎：** Jinja2
- **渲染：** Playwright (Chromium 截图)
- **数据格式：** JSON

### 数据占位符说明

```html
{{ date_str }}                  → "12月18日"
{{ weekday_str }}               → "星期三"
{{ lead.main_title }}           → 头条新闻标题
{{ lead.abstract_summary }}     → 头条摘要
{{ lead.bullet_points }}        → 要点列表（数组）
{{ lead.key_data }}             → 关键数据（数组）
```

### 渲染命令

```bash
# 在主项目目录运行
python card_render.py -t design_kit/card_template_v2.html -d design_kit/news_edit_review.json -o output.png
```

---

## 📞 需要帮助？

遇到问题请联系开发同学，或查看：

1. `协作说明.md` - 详细操作指南
2. `card_preview_with_data.html` - 在浏览器中实验
3. Chrome 开发者工具 - 实时调试 CSS

---

## 📝 版本历史

- **v2.0** (2025-12-18)
  - 新拟态风格设计
  - 支持关键数据卡片
  - 增加小便签效果
  - 优化头条布局

- **v1.0** (2025-12-01)
  - 初始版本
  - 极简扁平化设计

---

**🎉 祝设计愉快！有问题随时沟通~**

