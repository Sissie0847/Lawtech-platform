"""
快速测试脚本 - 从美术修改的模板生成卡片
用法：
    python quick_test.py
"""

import sys
import os

# 确保能找到上级目录的模块
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from card_render import render_card
    import asyncio
except ImportError as e:
    print(f"❌ 导入失败: {e}")
    print("请确保 card_render.py 在上级目录，且已安装依赖:")
    print("  pip install playwright jinja2")
    sys.exit(1)


async def main():
    """主测试函数"""
    print("\n" + "="*60)
    print("🚀 开始测试美术修改的模板")
    print("="*60 + "\n")
    
    template_file = "card_template_v2.html"
    data_file = "news_edit_review.json"
    output_file = "test_output.png"
    
    # 检查文件是否存在
    if not os.path.exists(template_file):
        print(f"❌ 未找到模板文件: {template_file}")
        print("请确保文件在当前目录")
        return
    
    if not os.path.exists(data_file):
        print(f"❌ 未找到数据文件: {data_file}")
        print("请确保文件在当前目录")
        return
    
    try:
        # 调用渲染函数
        result = await render_card(
            template_file=template_file,
            json_file=data_file,
            output_file=output_file,
            padding_top=50,
            padding_bottom=80
        )
        
        if result:
            print("\n" + "="*60)
            print(f"✅ 测试成功！图片已生成: {output_file}")
            print("="*60 + "\n")
            
            # 尝试打开图片
            try:
                import subprocess
                if sys.platform == 'win32':
                    os.startfile(output_file)
                elif sys.platform == 'darwin':  # macOS
                    subprocess.run(['open', output_file])
                else:  # Linux
                    subprocess.run(['xdg-open', output_file])
            except:
                print("提示：请手动打开查看生成的图片")
        else:
            print("\n❌ 测试失败")
            
    except Exception as e:
        print(f"\n❌ 发生错误: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    print("\n📦 美术协作工作包 - 快速测试工具")
    print("版本: 1.0")
    print("-" * 60)
    
    # 运行测试
    asyncio.run(main())

